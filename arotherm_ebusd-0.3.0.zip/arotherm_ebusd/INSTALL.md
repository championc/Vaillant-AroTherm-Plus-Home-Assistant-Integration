<!--
arotherm_ebusd INSTALL - version 0.3.0 (2026-10-28)

Changelog:
  0.1.0 (2026-10-28) - Initial release.
  0.2.0 (2026-10-28) - Zip name 0.2.0.
  0.2.1 (2026-10-28) - Zip name 0.2.1; upgrade note.
  0.2.2 (2026-10-28) - Zip name 0.2.2.
  0.3.0 (2026-10-28) - Zip name 0.3.0.
-->

# Installing aroTHERM ebusd 0.3.0

Your Home Assistant is **HA Container** (Docker) on 192.168.1.22, so there are no add-ons. That means no File editor or Samba add-on.
You copy the files onto the Docker host instead. Nothing in steps 1–5 changes anything on the heat pump or the controller.

## 1. Back up first

1. **HA backup:** *Settings → System → Backups → Back up now*. Then download the backup file to your PC.
2. **Config folder copy** on the host (192.168.1.22). First find where the HA config folder lives:
   ```bash
   docker inspect homeassistant --format '{{range .Mounts}}{{.Source}} -> {{.Destination}}{{"\n"}}{{end}}'
   ```
   The line ending in `-> /config` shows the host path. Below it's called `<HA_CONFIG>`. If your container isn't called `homeassistant`, check with `docker ps`.
   ```bash
   sudo tar czf ~/ha-config-backup-$(date +%F).tgz -C <HA_CONFIG> .
   ```
3. **ebusd compose file:** `cp docker-compose.yaml docker-compose.yaml.bak-$(date +%F)`.

## 2. Copy the integration

From your PC, copy the zip to the host (or use WinSCP):
```powershell
scp $env:USERPROFILE\Downloads\arotherm_ebusd-0.3.0.zip <user>@192.168.1.22:/tmp/
```
Then on the host:
```bash
sudo mkdir -p <HA_CONFIG>/custom_components
cd <HA_CONFIG>/custom_components
sudo unzip -o /tmp/arotherm_ebusd-0.3.0.zip      # creates arotherm_ebusd/
ls arotherm_ebusd                                 # __init__.py, manifest.json, ... translations/
```
The folder must be `<HA_CONFIG>/custom_components/arotherm_ebusd/`, not nested one level deeper.

## 3. Restart Home Assistant

Go to *Settings → System → ⋮ → Restart Home Assistant*, or run `docker restart homeassistant`.

## 4. Add the integration

1. Go to *Settings → Devices & services → Add integration* and search for **aroTHERM ebusd**.
2. Fill in:
   - Host: `192.168.1.22`
   - TCP command port: `8888`
   - HTTP/JSON port: `8889`
3. Submit. Setup only sends `info` and one HTTP GET. You get three devices: *aroTHERM plus*, *sensoCOMFORT VRC 720* and *ebusd*.

## 5. Tell me it's in

I'll then check the integration's values against ebusd's own data (`http://192.168.1.22:8889/data/hmu`) and the old MQTT entities, which are still running at that point.

## 6. Retire MQTT (after the check in step 5)

Do it in this order, so nothing that's still in use breaks:

1. **Disable** the automations **Ebusd-HMU-fast-poll** and **Ebusd - poll room temperature (sensoCOMFORT)**. **Ebusd-VRC-720** is already off. The integration now does this polling.
2. **Move these across** to the new entities. I can do this for you once the integration is running.
   - Dashboards: **Heat pump** (heat-pump), **lumina-energy-card** and **dashboard-test**.
   - Automation **Vaillant controller clock check (WhatsApp)**. It triggers on the MQTT topic `ebusd/broadcast/vdatetime`. It will be rewritten to use *sensoCOMFORT VRC 720 → Controller clock drift* instead.
   - Helpers *Heat Pump Compressor Starts Today* and *Heat Pump Flow Delta T*. These are replaced by *Compressor starts today* and *Flow/return difference*.
3. **ebusd compose file:**
   - Remove the lines from `--mqtthost=...` through `--mqttpass=...`. That includes `--mqttint`, `--mqttvar` and `--mqttjson`, and it also removes the MQTT password from the file.
   - Change `--pollinterval=10` to `--pollinterval=0`, so ebusd stops its own background polling of ~330 messages. The integration polls only what it needs.
   - Keep `--httpport=8889`, `--accesslevel=*`, `--scanconfig`, `--configpath=...` and `--device=...`.
   - Then run `docker compose up -d ebusd`.
4. **Remove the old MQTT devices:** go to *Settings → Devices & services → MQTT → Devices* and delete the ebusd devices (*ebusd*, *ebusd hmu*, *ebusd basv*, *ebusd vwzio*, *ebusd broadcast*, …). Deleting them in the UI also clears their retained discovery messages on the broker.

## Rolling back

1. Delete `<HA_CONFIG>/custom_components/arotherm_ebusd`.
2. Remove the integration in the UI.
3. Restart HA.
4. If you already did step 6, restore `docker-compose.yaml.bak-…` and re-enable the automations.
